const Button = ({label}) => {
    return <Button>
        {label}
    </Button>
}

export default Button