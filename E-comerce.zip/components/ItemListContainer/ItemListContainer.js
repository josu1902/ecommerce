const ItemListContainer = ({greeting}) => {
    return <h1>{greeting} </h1>
}

export default ItemListContainer