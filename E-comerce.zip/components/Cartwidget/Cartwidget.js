import cart from'./assets/cart.svg'

const Cartwidget = () => {
    return (
        <div>
            <img src={cart}></img>
            5
        </div>
    )
}
export default Cartwidget