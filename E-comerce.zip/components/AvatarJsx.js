const AvatarJsx = (props) => {
    console.log(props)
    const src = "C:\Users\maria\OneDrive\Documentos\Proyecto.vila\E-Comerce\IMG\Avatar/${id}.jpeg/"
    return (
        <picture>
            <img src={src} alt={marta}></img>
            {marta}
            {desc}
        </picture>

    )
} 
export default AvatarJsx