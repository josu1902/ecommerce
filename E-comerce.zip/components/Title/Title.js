const Title = ({title}) =>{
    return 
    <h1 style={{color: 'red'}}>{title} </h1>
}
export default Titleitle