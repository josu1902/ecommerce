import 'Navbar.css'

const Navbar= ()=> {
    return (
      <nav>
        <div>
            <h1>Ecomerce</h1>
        </div>
        <div>
            <button>Tortas</button>
        </div>
      </nav>
    )
}